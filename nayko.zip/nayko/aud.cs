﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class aud : MonoBehaviour {
    AudioSource myAudio;
	// Use this for initialization
	void Start () {
		myAudio = GetComponent<AudioSource>();
		Invoke("playAudio", 2f);
	}
	
	// Update is called once per frame
	void playAudio () {
		myAudio.Play();
	}
}
